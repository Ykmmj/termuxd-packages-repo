#
# /data/local/tmp/termuxd/runtime/usr/glibc/etc/bash.bash_logout
#
