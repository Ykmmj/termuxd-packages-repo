# config file for bash-completion
# https://github.com/scop/bash-completion

set (BASH_COMPLETION_VERSION "2.16.0")

set (BASH_COMPLETION_PREFIX "/data/local/tmp/termuxd/runtime/usr/glibc")

set (BASH_COMPLETION_COMPATDIR "/data/local/tmp/termuxd/runtime/usr/glibc/etc/bash_completion.d")
set (BASH_COMPLETION_COMPLETIONSDIR "/data/local/tmp/termuxd/runtime/usr/glibc/share/bash-completion/completions")
set (BASH_COMPLETION_HELPERSDIR "/data/local/tmp/termuxd/runtime/usr/glibc/share/bash-completion/helpers")

set (BASH_COMPLETION_FOUND "TRUE")
